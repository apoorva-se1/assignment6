package main

import (
    "encoding/json"
    "fmt"
    "io/ioutil"
    "os"
)

func main() {

    jsonFile, err:= os.Open("example.json")
    if err != nil {
        fmt.Println(err)
    }

    fmt.Println("Successfully Opened example.json")
    defer jsonFile.Close()

    byteValue,_:= ioutil.ReadAll(jsonFile)

    type Operations[] struct {
        Operation string `json:"Operation"`
        Units struct {
            One int `json:"one"`
            Two int `json:"two"`
        }`json:"Units"`
    }

    var operations Operations

    err = json.Unmarshal(byteValue, & operations)
    if err != nil {
        fmt.Println("error:", err)
    }

    for i:= 0; i < len(operations);i++{
        if operations[i].Operation  == "Add" {
            fmt.Printf("Addition: %d\n", operations[i].Units.One + operations[i].Units.Two);
        }
        if operations[i].Operation == "Subtract" {
            fmt.Printf("Subtraction: %d\n", operations[i].Units.One + operations[i].Units.Two);
        }
        if operations[i].Operation == "Multiply" {
            fmt.Printf("Multiplication: %d\n", operations[i].Units.One + operations[i].Units.Two);
        }
        if operations[i].Operation == "Divide" {
            fmt.Printf("Division: %d\n", operations[i].Units.One + operations[i].Units.Two);
        }

    }

}