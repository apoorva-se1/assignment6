package main

import (
    "encoding/json"
    "fmt"
    "io/ioutil"
)

func main() {
    
    data, err := ioutil.ReadFile("./example.json")
    if err != nil {
      fmt.Print(err)
    }

    type Fruits struct {
      Apple int
      Orange int
      Banana int
    }

    var obj Fruits

    err = json.Unmarshal(data, &obj)
    if err != nil {
        fmt.Println("error:", err)
    }

    fmt.Printf("Apple : %d\n", obj.Apple);
    fmt.Printf("Orange : %d\n", obj.Orange);
    fmt.Printf("Banana : %d\n", obj.Banana);

} 